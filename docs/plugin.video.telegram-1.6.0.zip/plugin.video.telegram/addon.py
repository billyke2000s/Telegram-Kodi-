import json
import os
import sys
import threading
import time
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qsl, urlencode
from urllib.request import Request, urlopen

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "lib"))

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402
import xbmcplugin  # noqa: E402

from tgkodi import common  # noqa: E402

BASE = sys.argv[0]
HANDLE = int(sys.argv[1])
PARAMS = dict(parse_qsl(sys.argv[2].lstrip("?")))
# Kodi passes content_type=video|image when opened from Videos / Pictures add-ons.
CT = PARAMS.get("ct") or ("image" if PARAMS.get("content_type") == "image" else "video")
ADDON = common.addon()
ICON = ADDON.getAddonInfo("icon")
FANART = ADDON.getAddonInfo("fanart")


class ApiError(Exception):
    def __init__(self, status, msg):
        Exception.__init__(self, msg)
        self.status = status
        self.msg = msg


class ServiceDown(Exception):
    pass


def api(path, data=None, timeout=600):
    token = common.get_token()
    if not token:
        raise ServiceDown()
    url = "%s/api/%s" % (common.base_url(token), path)
    body = json.dumps(data).encode("utf-8") if data is not None else None
    req = Request(url, data=body, headers={"Content-Type": "application/json"})
    try:
        with urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8"))
    except HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8")).get("error", "")
        except Exception:
            msg = str(e)
        raise ApiError(e.code, msg)
    except URLError:
        raise ServiceDown()


def url_for(**kw):
    kw.setdefault("ct", CT)
    return BASE + "?" + urlencode(kw)


def media_url(kind, cid, mid, ext=".jpg"):
    b = common.base_url()
    if kind == "stream":
        return "%s/stream/%d/%d/video%s" % (b, cid, mid, ext)
    if kind == "photo":
        return "%s/photo/%d/%d/image.jpg" % (b, cid, mid)
    if kind == "thumb":
        return "%s/thumb/%d/%d.jpg" % (b, cid, mid)
    if kind == "avatar":
        return "%s/avatar/%d.jpg" % (b, cid)


def notify(msg, title="Telegram", ms=5000):
    xbmcgui.Dialog().notification(title, msg, ICON, ms)


def add_dir(label, url, thumb=None, plot="", folder=True, context=None):
    li = xbmcgui.ListItem(label)
    art = {"icon": thumb or ICON, "thumb": thumb or ICON, "fanart": FANART}
    li.setArt(art)
    if plot:
        set_plot(li, plot)
    if context:
        li.addContextMenuItems(context)
    if not folder:
        li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(HANDLE, url, li, isFolder=folder)


def set_plot(li, plot):
    try:
        li.getVideoInfoTag().setPlot(plot)
    except AttributeError:  # very old Kodi
        li.setInfo("video", {"plot": plot})


def refresh_ctx():
    return [("Refresh from Telegram", "RunPlugin(%s)" % url_for(mode="refresh"))]


def end(content=None, sort_none=True):
    if content:
        xbmcplugin.setContent(HANDLE, content)
    if sort_none:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=False)


# ------------------------------------------------------------------ screens

def root():
    try:
        st = api("status", timeout=60)
    except ServiceDown:
        add_dir("[COLOR red]Background service not running[/COLOR] - restart Kodi", url_for(mode="status"),
                folder=False, plot="The add-on's service starts when Kodi starts. If you just installed it, restart Kodi.")
        return end()
    if not st.get("configured"):
        add_dir("Step 1: Enter your API ID and API hash", url_for(mode="settings"), folder=False,
                plot="Get them at https://my.telegram.org -> API development tools, then come back here.")
        return end()
    if not st.get("authorized"):
        if st.get("error"):
            add_dir("[COLOR red]%s[/COLOR]" % st["error"], url_for(mode="status"), folder=False)
        add_dir("Step 2: Log in with QR code (recommended)", url_for(mode="login_qr"), folder=False,
                plot="Shows a QR code on screen. On your phone open Telegram > Settings > Devices > "
                     "Link Desktop Device and scan it. No login code needed. If your account has a "
                     "two-step verification password you'll be asked for it afterwards.")
        add_dir("Log in with phone number instead", url_for(mode="login"), folder=False,
                plot="You'll be asked for your phone number, the code Telegram sends you, and your 2FA password if you have one.")
        add_dir("Settings", url_for(mode="settings"), folder=False)
        return end()

    try:
        dialogs = api("dialogs")["dialogs"]
    except ApiError as e:
        notify("Couldn't load chats: %s" % e.msg)
        dialogs = []

    for kind, label in (("all", "Mixed"), ("photo", "Images"), ("video", "Videos")):
        add_dir("[B]All %s[/B]" % label, url_for(mode="media", chats="all", kind=kind, title="All " + label),
                plot="%s from every included chat, newest first." % label, context=refresh_ctx())
    add_dir("[B]Search[/B]", url_for(mode="search_prompt", chats="all", title="All chats"), folder=False,
            plot="Find photos and videos by caption or file name across all your chats.")
    saved = [d for d in dialogs if d["title"] == "Saved Messages" and d["type"] == "user"]
    if saved:
        add_chat(saved[0])

    inc = {"channel": common.setting_bool("include_channels"),
           "group": common.setting_bool("include_groups"),
           "user": common.setting_bool("include_private")}
    unread = [d for d in dialogs if d.get("unread") and inc.get(d["type"])]
    add_dir("[B]Unread (%d chats)[/B]" % len(unread), url_for(mode="unread"),
            plot="Chats with unread messages, most recent first, plus their new photos and videos.",
            context=refresh_ctx())
    groups = [d for d in dialogs if d["type"] == "group"]
    users = [d for d in dialogs if d["type"] == "user"]
    if inc["group"] and groups:
        add_dir("[B]Groups (%d)[/B]" % len(groups), url_for(mode="chats", type="group"), context=refresh_ctx())
    if inc["user"] and users:
        add_dir("[B]Private chats (%d)[/B]" % len(users), url_for(mode="chats", type="user"), context=refresh_ctx())
    if inc["channel"]:
        for d in dialogs:
            if d["type"] == "channel":
                add_chat(d)

    add_dir("[I]Refresh[/I]", url_for(mode="refresh"), folder=False)
    add_dir("[I]Account: %s  |  crypto: %s[/I]" % (st.get("user", "?"), st.get("crypto", "?")),
            url_for(mode="status"), folder=False)
    add_dir("[I]Settings[/I]", url_for(mode="settings"), folder=False)
    add_dir("[I]Clear cache[/I]", url_for(mode="clear_cache"), folder=False,
            plot="Delete downloaded thumbnails/photos and forget cached lists.")
    add_dir("[I]Log out[/I]", url_for(mode="logout"), folder=False)
    end()


def add_chat(d):
    thumb = media_url("avatar", d["id"], 0) if d.get("has_photo") else None
    label = d["title"]
    if d.get("unread"):
        label += "  [COLOR grey](%d unread)[/COLOR]" % d["unread"]
    ctx = [("Search in this chat", "RunPlugin(%s)" % url_for(mode="search_prompt", chats=d["id"], title=d["title"]))]
    if d.get("unread"):
        ctx.append(("Mark as read", "RunPlugin(%s)" % url_for(mode="read", chat=d["id"])))
    add_dir(label, url_for(mode="chat", id=d["id"], title=d["title"], unread=d.get("unread") or 0),
            thumb=thumb, context=ctx + refresh_ctx())


def chats(typ):
    dialogs = api("dialogs")["dialogs"]
    for d in dialogs:
        if d["type"] == typ:
            add_chat(d)
    end()


def unread_menu():
    dialogs = api("dialogs")["dialogs"]
    inc = {"channel": common.setting_bool("include_channels"),
           "group": common.setting_bool("include_groups"),
           "user": common.setting_bool("include_private")}
    for kind, label in (("all", "Mixed"), ("photo", "Images"), ("video", "Videos")):
        add_dir("[B]All unread %s[/B]" % label,
                url_for(mode="media", chats="all", kind=kind, unread=1, title="Unread " + label),
                plot="New %s from every chat with unread messages, newest first." % label.lower(),
                context=refresh_ctx())
    for d in dialogs:  # Telegram's own order: most recent activity first
        if d.get("unread") and inc.get(d["type"]):
            add_chat(d)
    end()


def chat(cid, title, unread=0):
    if unread:
        for kind, label in (("all", "Mixed"), ("photo", "Images"), ("video", "Videos")):
            add_dir("[B]Unread %s[/B]" % label,
                    url_for(mode="media", chats=str(cid), kind=kind, unread=1,
                            title="%s - Unread %s" % (title, label)),
                    plot="Only photos/videos posted after the last message you read.",
                    context=refresh_ctx())
    for kind, label in (("all", "Mixed"), ("photo", "Images"), ("video", "Videos")):
        add_dir(label, url_for(mode="media", chats=str(cid), kind=kind, title="%s - %s" % (title, label)),
                context=refresh_ctx())
    add_dir("Search in this chat", url_for(mode="search_prompt", chats=cid, title=title), folder=False)
    if unread:
        add_dir("Mark as read", url_for(mode="read", chat=cid), folder=False)
    end()


def fmt_dur(sec):
    if not sec:
        return ""
    h, r = divmod(int(sec), 3600)
    m, s = divmod(r, 60)
    return "%d:%02d:%02d" % (h, m, s) if h else "%d:%02d" % (m, s)


def page_query(p):
    """API path for one page of a listing described by params p (media or search)."""
    q = {"chats": p.get("chats", "all"), "kind": p.get("kind", "all"),
         "n": common.setting_int("page_size", 50, 10, 200)}
    if p.get("cursor"):
        q["cursor"] = p["cursor"]
    if p.get("src") == "search":
        q["q"] = p.get("q", "")
        return "search?" + urlencode(q)
    if str(p.get("unread")) == "1":
        q["unread"] = "1"
    return "media?" + urlencode(q)


def fetch_page(p):
    return api(page_query(p))


def media(chats_param, kind, cursor, title, unread=False, src="media", query=""):
    listing = {"chats": chats_param, "kind": kind, "cursor": cursor or "", "title": title,
               "unread": 1 if unread else 0, "src": src, "q": query}
    res = fetch_page(listing)
    combined = chats_param == "all"
    items = res["items"]
    if any(it["kind"] == "video" for it in items) and CT != "image":
        add_dir("[B]Play all videos[/B]", url_for(mode="playall", **listing), folder=False, thumb=ICON,
                plot="Plays every video on this page in order. Use Next/Previous on the remote to skip.")
    for it in items:
        add_media_item(it, combined or src == "search", listing)
    if not items and not cursor:
        msg = " - no unread photos/videos" if unread else (" for '%s'" % query if src == "search" else "")
        add_dir("[I]Nothing here%s[/I]" % msg, url_for(mode="refresh"), folder=False)
    page = int(PARAMS.get("page", "1") or 1)
    if res.get("next"):
        nxt = dict(listing, cursor=res["next"])
        add_dir("[B]Next page (%d) >>[/B]" % (page + 1),
                url_for(mode="media", page=page + 1, **nxt), thumb=ICON, plot="Older items")
    end("images" if CT == "image" else "videos")
    if common.setting_bool("wall_view", True):
        xbmc.executebuiltin("Container.SetViewMode(500)")  # Estuary "Wall"; ignored if absent


def fmt_size(n):
    if not n:
        return ""
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return ("%d %s" if unit in ("B", "KB") else "%.1f %s") % (n, unit)
        n /= 1024.0


def item_ctx(it, listing):
    cid, mid = it["chat_id"], it["msg_id"]
    start = "%d_%d" % (cid, mid)
    ctx = []
    if it["kind"] == "video":
        ctx.append(("Play all videos from here", "RunPlugin(%s)" % url_for(mode="playall", start=start, **listing)))
    ctx.append(("Open in full-screen viewer", "RunPlugin(%s)" % url_for(mode="viewer", start=start, **listing)))
    if listing.get("chats") == "all" or listing.get("src") == "search":
        ctx.append(("Go to chat: %s" % (it.get("chat_title") or "chat"),
                    "Container.Update(%s)" % url_for(mode="chat", id=cid, title=it.get("chat_title") or "")))
    ctx.append(("Save to device", "RunPlugin(%s)" % url_for(mode="save", chat=cid, msg=mid)))
    ctx.append(("Mark chat as read", "RunPlugin(%s)" % url_for(mode="read", chat=cid)))
    return ctx + refresh_ctx()


def add_media_item(it, combined, listing=None):
    cid, mid = it["chat_id"], it["msg_id"]
    text = (it.get("text") or "").strip()
    first = text.splitlines()[0][:90] if text else ""
    when = time.strftime("%Y-%m-%d %H:%M", time.localtime(it["date"]))
    label = first or it.get("name") or ("Photo" if it["kind"] == "photo" else "Video") + " " + when
    if it["kind"] == "video" and it.get("duration"):
        label += "  [COLOR grey](%s)[/COLOR]" % fmt_dur(it["duration"])
    if combined and it.get("chat_title"):
        label = "[COLOR grey]%s:[/COLOR] %s" % (it["chat_title"], label)
    thumb = media_url("thumb", cid, mid)
    if it["kind"] == "video":
        res_p = min(it.get("w") or 0, it.get("h") or 0)
        extra = [x for x in (fmt_dur(it.get("duration")), ("%dp" % res_p) if res_p else "",
                             fmt_size(it.get("size"))) if x]
        if extra:
            label = label.split("  [COLOR grey](")[0] + "  [COLOR grey](%s)[/COLOR]" % " | ".join(extra)
    li = xbmcgui.ListItem(label, when)
    if listing:
        li.addContextMenuItems(item_ctx(it, listing))
    try:
        li.setDateTime(time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(it["date"])))
    except Exception:
        pass

    if it["kind"] == "photo":
        full = media_url("photo", cid, mid)
        li.setArt({"thumb": thumb, "icon": thumb, "poster": thumb, "fanart": full})
        if CT == "image":
            li.setInfo("pictures", {"title": label})
            li.setMimeType("image/jpeg")
            path = full
        else:
            set_plot(li, text)
            li.setProperty("IsPlayable", "false")
            if listing:
                path = url_for(mode="viewer", start="%d_%d" % (cid, mid), **listing)
            else:
                path = url_for(mode="show_image", url=full)
        xbmcplugin.addDirectoryItem(HANDLE, path, li, isFolder=False)
        return

    path = media_url("stream", cid, mid, it.get("ext") or ".mp4")
    li.setArt({"thumb": thumb, "icon": thumb, "poster": thumb})
    li.setMimeType(it.get("mime") or "video/mp4")
    li.setContentLookup(False)
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(first or it.get("name") or "Video " + when)
        tag.setPlot(text)
        if it.get("duration"):
            tag.setDuration(int(it["duration"]))
        tag.setMediaType("video")
        if it.get("w") and it.get("h"):  # lets the skin show resolution badges
            tag.addVideoStream(xbmc.VideoStreamDetail(width=it["w"], height=it["h"],
                                                      duration=int(it.get("duration") or 0)))
    except AttributeError:
        li.setInfo("video", {"title": first or it.get("name") or "Video " + when, "plot": text, "duration": it.get("duration") or 0})
    xbmcplugin.addDirectoryItem(HANDLE, path, li, isFolder=False)


# ------------------------------------------------------------------ actions

class QrWindow(xbmcgui.WindowDialog):
    """Full-screen QR code. WindowDialog uses a 1280x720 coordinate space."""
    CENTER = 0x00000002  # XBFONT_CENTER_X
    BACK_ACTIONS = (9, 10, 92, 13)  # parent dir, previous menu, back, stop

    def __init__(self, backdrop):
        xbmcgui.WindowDialog.__init__(self)
        self.closed = False
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, backdrop, colorDiffuse="F0000000"))
        self.addControl(xbmcgui.ControlLabel(
            0, 40, 1280, 40, "[B]Log in to Telegram[/B]", font="font30",
            textColor="0xFFFFFFFF", alignment=self.CENTER))
        self.qr = xbmcgui.ControlImage(450, 110, 380, 380, "")
        self.addControl(self.qr)
        self.status = xbmcgui.ControlLabel(
            0, 505, 1280, 30, "Getting a code from Telegram...", font="font13",
            textColor="0xFFFFFFFF", alignment=self.CENTER)
        self.addControl(self.status)
        for i, line in enumerate((
                "On your phone open Telegram > Settings > Devices > Link Desktop Device",
                "and point the camera at this code. It refreshes automatically.",
                "Press Back to cancel.")):
            self.addControl(xbmcgui.ControlLabel(
                0, 550 + i * 32, 1280, 30, line, font="font13",
                textColor="0xFFCCCCCC", alignment=self.CENTER))

    def set_qr(self, path):
        self.qr.setImage(path, False)
        self.status.setLabel("Waiting for you to scan...")

    def onAction(self, action):
        if action.getId() in self.BACK_ACTIONS:
            self.closed = True
            self.close()


def _qr_files():
    from tgkodi import qrimage
    folder = os.path.join(common.profile_dir(), "qr")
    os.makedirs(folder, exist_ok=True)
    for name in os.listdir(folder):  # old codes are useless once replaced
        if name.startswith("qr_"):
            try:
                os.remove(os.path.join(folder, name))
            except OSError:
                pass
    backdrop = os.path.join(folder, "backdrop.png")
    if not os.path.exists(backdrop):
        qrimage.write_solid(backdrop)
    return folder, backdrop


def login_qr():
    from tgkodi import qrimage
    dlg = xbmcgui.Dialog()
    try:
        st = api("login/qr/start", {}, timeout=60)
    except ApiError as e:
        dlg.ok("Telegram", "Couldn't start QR login:\n%s" % e.msg)
        return
    if st.get("state") == "done":
        notify("Already logged in")
        xbmc.executebuiltin("Container.Refresh")
        return

    folder, backdrop = _qr_files()
    win = QrWindow(backdrop)
    win.show()
    monitor = xbmc.Monitor()
    shown, n = None, 0
    try:
        while not win.closed and not monitor.abortRequested():
            state = st.get("state")
            if state == "waiting" and st.get("url") != shown:
                n += 1
                # Unique name per code, otherwise Kodi's texture cache shows the old one.
                path = os.path.join(folder, "qr_%d_%d.png" % (int(time.time()), n))
                qrimage.write_qr(st["url"], path)
                win.set_qr(path)
                shown = st["url"]
            elif state not in ("waiting", "starting"):
                break
            if monitor.waitForAbort(1):
                break
            st = api("login/qr/status", timeout=30)
    finally:
        cancelled = win.closed
        win.close()
        del win
        _qr_files()

    state = st.get("state")
    if cancelled or state in ("waiting", "starting"):
        try:
            api("login/qr/cancel", {}, timeout=30)
        except (ApiError, ServiceDown):
            pass
        return
    if state == "need_password":
        if not _ask_password(dlg):
            return
    elif state == "done":
        notify("Logged in")
    elif state == "expired":
        dlg.ok("Telegram", "The QR code timed out. Choose 'Log in with QR code' to try again.")
        return
    else:
        dlg.ok("Telegram", "QR login failed:\n%s" % (st.get("error") or state))
        return
    xbmc.executebuiltin("Container.Refresh")


def _ask_password(dlg):
    """Two-step verification. Returns True once logged in."""
    pw = dlg.input("Two-step verification password (your Telegram cloud password)",
                   option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not pw:
        return False
    try:
        res = api("login/password", {"password": pw}, timeout=120)
    except ApiError as e:
        dlg.ok("Telegram", "Login failed:\n%s" % e.msg)
        return False
    if res.get("ok"):
        notify("Logged in")
        return True
    dlg.ok("Telegram", "Login did not complete.")
    return False


def login():
    dlg = xbmcgui.Dialog()
    phone = dlg.input("Phone number in international format (e.g. +447700900123)")
    if not phone:
        return
    try:
        api("login/send_code", {"phone": phone}, timeout=120)
    except ApiError as e:
        dlg.ok("Telegram", "Couldn't send code:\n%s" % e.msg)
        return
    code = dlg.input("Login code (sent to your Telegram app / SMS)", type=xbmcgui.INPUT_NUMERIC)
    if not code:
        return
    try:
        res = api("login/code", {"code": code}, timeout=120)
        if res.get("need_password"):
            pw = dlg.input("Two-step verification password", option=xbmcgui.ALPHANUM_HIDE_INPUT)
            if not pw:
                return
            res = api("login/password", {"password": pw}, timeout=120)
    except ApiError as e:
        dlg.ok("Telegram", "Login failed:\n%s" % e.msg)
        return
    if res.get("ok"):
        notify("Logged in")
    else:
        dlg.ok("Telegram", "Login did not complete.")
    xbmc.executebuiltin("Container.Refresh")


class PhotoViewer(xbmcgui.WindowDialog):
    """Full-screen viewer for a media listing: left/right = previous/next, OK on a video
    plays it, Back closes. Carries on into the next page automatically. Kodi's own
    SlideShow() sorts by label and can't page, so we drive navigation ourselves."""
    LEFT, RIGHT, UP, DOWN, SELECT = 1, 2, 3, 4, 7
    NEXT_ITEM, PREV_ITEM, MOUSE_CLICK = 14, 15, 100
    PLAY_PAUSE = (12, 79, 229)        # pause, play, play/pause
    INFO, MENU = 11, (117, 9001)      # info key, context-menu key / long press
    BACK = (9, 10, 92, 13)
    CENTER = 0x00000002

    def __init__(self, items, index, next_cursor, query):
        xbmcgui.WindowDialog.__init__(self)
        self.items, self.index, self.next_cursor, self.query = items, index, next_cursor, query
        self.play_item = None
        self.goto_chat = None
        self.auto = False
        self.closed = False
        self.bar_visible = True
        backdrop = _backdrop()
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, backdrop))
        # sits behind the picture, so it's only visible until the picture has loaded
        self.addControl(xbmcgui.ControlLabel(0, 340, 1280, 40, "Loading...", font="font13",
                                             textColor="0xFF888888", alignment=self.CENTER))
        self.image = xbmcgui.ControlImage(0, 0, 1280, 720, "", aspectRatio=2)
        self.addControl(self.image)
        self.bar = xbmcgui.ControlImage(0, 672, 1280, 48, backdrop, colorDiffuse="B0000000")
        self.addControl(self.bar)
        self.info = xbmcgui.ControlLabel(20, 680, 1240, 32, "", font="font12",
                                         textColor="0xFFFFFFFF", alignment=self.CENTER)
        self.addControl(self.info)
        self.show_current()

    def show_current(self):
        it = self.items[self.index]
        cid, mid = it["chat_id"], it["msg_id"]
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime(it["date"]))
        text = (it.get("text") or "").strip().splitlines()
        parts = ["%d / %d%s" % (self.index + 1, len(self.items), "+" if self.next_cursor else "")]
        if it.get("chat_title"):
            parts.append(it["chat_title"])
        parts.append(when)
        if it["kind"] == "video":
            parts.append("[B]VIDEO - press OK to play[/B]")
            url = media_url("thumb", cid, mid)
            _prefetch_video(cid, mid)
        else:
            url = media_url("photo", cid, mid)
        if text:
            parts.append(text[0][:80])
        if self.auto:
            parts.insert(0, "[B]SLIDESHOW[/B] (Play/Pause to stop)")
        self.image.setImage(url, False)
        self.info.setLabel("   |   ".join(parts))
        self.prefetch()

    def prefetch(self):
        """Ask the local server to download the neighbours now, so they're instant."""
        urls = []
        for j in (self.index + 1, self.index + 2, self.index - 1):
            if 0 <= j < len(self.items):
                it = self.items[j]
                urls.append(media_url("photo" if it["kind"] == "photo" else "thumb", it["chat_id"], it["msg_id"]))

        def run():
            for u in urls:
                try:
                    with urlopen(u, timeout=120) as r:
                        r.read()
                except Exception:
                    pass
        threading.Thread(target=run, daemon=True).start()

    def move(self, step):
        j = self.index + step
        if j >= len(self.items) and self.next_cursor:
            self.info.setLabel("Loading more...")
            q = dict(self.query, cursor=self.next_cursor)
            try:
                res = fetch_page(q)
                self.items.extend(res["items"])
                self.next_cursor = res.get("next")
            except (ApiError, ServiceDown) as e:
                notify("Couldn't load more: %s" % e)
                self.next_cursor = None
        if 0 <= j < len(self.items):
            self.index = j
        self.show_current()

    def toggle_slideshow(self):
        self.auto = not self.auto
        self.show_current()
        if self.auto:
            threading.Thread(target=self._slideshow_loop, daemon=True).start()

    def _slideshow_loop(self):
        delay = common.setting_int("slideshow_seconds", 5, 2, 60)
        monitor = xbmc.Monitor()
        while self.auto and not self.closed:
            if monitor.waitForAbort(delay) or not self.auto or self.closed:
                break
            before = self.index
            self.move(1)
            if self.index == before:  # reached the end
                self.auto = False
                self.show_current()

    def toggle_bar(self):
        self.bar_visible = not self.bar_visible
        self.bar.setVisible(self.bar_visible)
        self.info.setVisible(self.bar_visible)

    def options(self):
        it = self.items[self.index]
        labels = ["Stop slideshow" if self.auto else "Start slideshow",
                  "Hide caption bar" if self.bar_visible else "Show caption bar",
                  "Save to device", "Go to chat: %s" % (it.get("chat_title") or "chat"),
                  "Mark chat as read"]
        if it["kind"] == "video":
            labels.insert(0, "Play video")
        choice = xbmcgui.Dialog().contextmenu(labels)
        if choice < 0:
            return
        pick = labels[choice]
        if pick == "Play video":
            self.play_item = it
            self.close()
        elif pick.endswith("slideshow"):
            self.toggle_slideshow()
        elif pick.endswith("caption bar"):
            self.toggle_bar()
        elif pick == "Save to device":
            save_item(it["chat_id"], it["msg_id"])
        elif pick.startswith("Go to chat"):
            self.goto_chat = it
            self.close()
        elif pick == "Mark chat as read":
            mark_read(it["chat_id"])

    def close(self):
        self.closed = True
        self.auto = False
        xbmcgui.WindowDialog.close(self)

    def onAction(self, action):
        a = action.getId()
        if a in self.PLAY_PAUSE:
            self.toggle_slideshow()
            return
        if a == self.INFO:
            self.toggle_bar()
            return
        if a in self.MENU:
            self.options()
            return
        if a in (self.RIGHT, self.NEXT_ITEM, self.DOWN, self.MOUSE_CLICK):
            self.move(1)
        elif a in (self.LEFT, self.PREV_ITEM, self.UP):
            self.move(-1)
        elif a == self.SELECT:
            it = self.items[self.index]
            if it["kind"] == "video":
                self.play_item = it
                self.close()
            else:
                self.move(1)
        elif a in self.BACK:
            self.close()


def _prefetch_video(cid, mid):
    """Tell the service to start downloading the video's beginning in the background."""
    def run():
        try:
            api("prefetch?" + urlencode({"chat": cid, "msg": mid}), timeout=10)
        except Exception:
            pass
    threading.Thread(target=run, daemon=True).start()


def _backdrop():
    from tgkodi import qrimage
    folder = os.path.join(common.profile_dir(), "qr")
    os.makedirs(folder, exist_ok=True)
    path = os.path.join(folder, "backdrop.png")
    if not os.path.exists(path):
        qrimage.write_solid(path)
    return path


def listing_from(p):
    return {k: p.get(k, "") for k in ("chats", "kind", "cursor", "unread", "src", "q", "title")}


def viewer(p):
    q = listing_from(p)
    res = fetch_page(q)
    items = res["items"]
    if not items:
        notify("Nothing to show")
        return
    start = p.get("start", "")
    if start.startswith("http"):  # links from 1.3.0: .../photo/<cid>/<mid>/image.jpg
        bits = start.split("/photo/", 1)[-1].split("/")
        start = "%s_%s" % (bits[0], bits[1]) if len(bits) >= 2 else ""
    index = 0
    for i, it in enumerate(items):
        if "%d_%d" % (it["chat_id"], it["msg_id"]) == start:
            index = i
            break
    next_cursor = res.get("next")
    monitor = xbmc.Monitor()
    while True:
        win = PhotoViewer(items, index, next_cursor, q)
        win.doModal()
        it, index, next_cursor, goto = win.play_item, win.index, win.next_cursor, win.goto_chat
        del win
        if goto:
            xbmc.executebuiltin("Container.Update(%s)" % url_for(
                mode="chat", id=goto["chat_id"], title=goto.get("chat_title") or ""))
            return
        if not it:
            return
        # Play, then return to the viewer at the same place when the video ends/stops.
        player = xbmc.Player()
        play_video(it)
        for _ in range(60):  # wait up to 30 s for playback to start
            if player.isPlaying() or monitor.waitForAbort(0.5):
                break
        while player.isPlaying() and not monitor.waitForAbort(0.5):
            pass
        if monitor.abortRequested():
            return


def play_all(p):
    """Queue every video on the page (from the chosen one, if any) and play."""
    res = fetch_page(listing_from(p))
    vids = [it for it in res["items"] if it["kind"] == "video"]
    start = p.get("start")
    if start:
        keys = ["%d_%d" % (v["chat_id"], v["msg_id"]) for v in vids]
        if start in keys:
            vids = vids[keys.index(start):]
    if not vids:
        notify("No videos on this page")
        return
    pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    pl.clear()
    for it in vids:
        url = media_url("stream", it["chat_id"], it["msg_id"], it.get("ext") or ".mp4")
        title = (it.get("text") or "").strip().split("\n")[0][:90] or it.get("name") or "Video"
        li = xbmcgui.ListItem(title, path=url)
        li.setArt({"thumb": media_url("thumb", it["chat_id"], it["msg_id"])})
        li.setMimeType(it.get("mime") or "video/mp4")
        li.setContentLookup(False)
        pl.add(url, li)
    _prefetch_video(vids[0]["chat_id"], vids[0]["msg_id"])
    xbmc.Player().play(pl)


def search_prompt(p):
    home = xbmcgui.Window(10000)
    last = home.getProperty("tg.last_search")
    where = p.get("title") or "all chats"
    query = xbmcgui.Dialog().input("Search %s" % where, defaultt=last)
    if not query:
        return
    home.setProperty("tg.last_search", query)
    kind = xbmcgui.Dialog().select("Search for", ["Photos and videos", "Photos only", "Videos only"])
    if kind < 0:
        return
    xbmc.executebuiltin("Container.Update(%s)" % url_for(
        mode="media", src="search", q=query, chats=p.get("chats", "all"),
        kind=("all", "photo", "video")[kind], title="Search: %s" % query))


def mark_read(chat):
    try:
        api("read", {"chat": int(chat)}, timeout=60)
        notify("Marked as read")
    except (ApiError, ServiceDown) as e:
        notify("Couldn't mark as read: %s" % e)


def save_item(chat, msg):
    folder = common.setting("download_folder")
    if not folder:
        folder = xbmcgui.Dialog().browse(3, "Choose where to save Telegram files", "files")
        if not folder:
            return
        ADDON.setSetting("download_folder", folder)
    import xbmcvfs
    path = xbmcvfs.translatePath(folder)
    try:
        api("save", {"chat": int(chat), "msg": int(msg), "folder": path}, timeout=30)
        notify("Saving in the background...")
    except (ApiError, ServiceDown) as e:
        notify("Couldn't save: %s" % e)


def clear_cache():
    if not xbmcgui.Dialog().yesno("Telegram", "Delete cached thumbnails and photos and reload lists?"):
        return
    try:
        api("clear_cache", {}, timeout=120)
        notify("Cache cleared")
    except (ApiError, ServiceDown) as e:
        notify("Couldn't clear cache: %s" % e)
    xbmc.executebuiltin("Container.Refresh")


def play_video(it):
    url = media_url("stream", it["chat_id"], it["msg_id"], it.get("ext") or ".mp4")
    li = xbmcgui.ListItem((it.get("text") or "").strip().split("\n")[0][:90] or "Video", path=url)
    li.setMimeType(it.get("mime") or "video/mp4")
    li.setContentLookup(False)
    xbmc.Player().play(url, li)


def logout():
    if not xbmcgui.Dialog().yesno("Telegram", "Log out and delete the saved session on this device?"):
        return
    try:
        api("logout", {}, timeout=60)
    except (ApiError, ServiceDown) as e:
        notify("Logout error: %s" % e)
    xbmc.executebuiltin("Container.Refresh")


def status():
    try:
        st = api("status", timeout=60)
        msg = "\n".join("%s: %s" % (k, v) for k, v in st.items())
    except ServiceDown:
        msg = "Background service is not reachable on 127.0.0.1:%d.\nRestart Kodi." % common.port()
    xbmcgui.Dialog().textviewer("Telegram status", msg)


def router():
    mode = PARAMS.get("mode")
    try:
        if mode is None:
            root()
        elif mode == "chats":
            chats(PARAMS.get("type", "group"))
        elif mode == "chat":
            chat(int(PARAMS["id"]), PARAMS.get("title", ""), int(PARAMS.get("unread", 0) or 0))
        elif mode == "unread":
            unread_menu()
        elif mode == "media":
            media(PARAMS.get("chats", "all"), PARAMS.get("kind", "all"), PARAMS.get("cursor"),
                  PARAMS.get("title", ""), PARAMS.get("unread") == "1",
                  PARAMS.get("src") or "media", PARAMS.get("q", ""))
        elif mode == "playall":
            play_all(PARAMS)
        elif mode == "search_prompt":
            search_prompt(PARAMS)
        elif mode == "read":
            mark_read(PARAMS["chat"])
            xbmc.executebuiltin("Container.Refresh")
        elif mode == "save":
            save_item(PARAMS["chat"], PARAMS["msg"])
        elif mode == "clear_cache":
            clear_cache()
        elif mode == "show_image":
            xbmc.executebuiltin("ShowPicture(%s)" % PARAMS["url"])
        elif mode in ("viewer", "slideshow"):  # slideshow = links from 1.3.0
            viewer(PARAMS)
        elif mode == "login":
            login()
        elif mode == "login_qr":
            login_qr()
        elif mode == "logout":
            logout()
        elif mode == "settings":
            ADDON.openSettings()
            xbmc.executebuiltin("Container.Refresh")
        elif mode == "status":
            status()
        elif mode == "refresh":
            api("refresh", {}, timeout=60)
            xbmc.executebuiltin("Container.Refresh")
    except ServiceDown:
        notify("Background service not running - restart Kodi")
        if mode in ("chats", "chat", "media", "unread"):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
    except ApiError as e:
        if e.status == 401:
            notify("Not logged in")
        else:
            notify("Error: %s" % e.msg)
        if mode in ("chats", "chat", "media", "unread"):
            xbmcplugin.endOfDirectory(HANDLE, succeeded=False)


router()
